package com.quickrabbitpartner.app.map;

public class School_lat_longPajo {
    private Double map_lat=0.0;
    private Double map_long=0.0;
    private String map_txt="";
    public Double getMap_long() {
        return map_long;
    }
    public void setMap_long(Double map_long) {
        this.map_long = map_long;
    }
    public Double getMap_lat() {
        return map_lat;
    }
    public void setMap_lat(Double map_lat) {
        this.map_lat = map_lat;
    }
    public String getMap_txt() {
        return map_txt;
    }
    public void setMap_txt(String map_txt) {
        this.map_txt = map_txt;
    }
}
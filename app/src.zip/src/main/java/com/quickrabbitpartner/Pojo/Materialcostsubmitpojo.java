package com.quickrabbitpartner.Pojo;

/**
 * Created by user145 on 5/26/2017.
 */
public class Materialcostsubmitpojo {

    private String toolname="";
    private String toolcost="";

    public String getToolname() {
        return toolname;
    }

    public void setToolname(String toolname) {
        this.toolname = toolname;
    }

    public String getToolcost() {
        return toolcost;
    }

    public void setToolcost(String toolcost) {
        this.toolcost = toolcost;
    }
}

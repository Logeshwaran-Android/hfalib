package com.quickrabbitpartner.Pojo;

/**
 * Created by user88 on 1/8/2016.
 */
public class WorkFlow_Pojo {
    private String jobstatus;
    private String job_title;
    private String job_date;
    private String job_time;

    public String getJobstatus() {
        return jobstatus;
    }

    public void setJobstatus(String jobstatus) {
        this.jobstatus = jobstatus;
    }

    public String getJob_title() {
        return job_title;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    public String getJob_time() {
        return job_time;
    }

    public void setJob_time(String job_time) {
        this.job_time = job_time;
    }

    public String getJobs_check() {
        return jobs_check;
    }

    public void setJobs_check(String jobs_check) {
        this.jobs_check = jobs_check;
    }

    public String getJob_date() {
        return job_date;
    }

    public void setJob_date(String job_date) {
        this.job_date = job_date;
    }

    private String jobs_check;



}

package com.quickrabbitpartner.Pojo;

/**
 * Created by CAS63 on 10/3/2017.
 */

public class ExperianceCategoryPojo {
    private String name = "";
    private String id = "";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

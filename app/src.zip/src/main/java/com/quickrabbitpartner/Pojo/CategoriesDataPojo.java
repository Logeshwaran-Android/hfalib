package com.quickrabbitpartner.Pojo;

import java.util.ArrayList;

public class CategoriesDataPojo {

    private ArrayList<SavedCategoryPojo> pojoArrayList;

    public ArrayList<SavedCategoryPojo> getPojoArrayList() {
        return pojoArrayList;
    }

    public void setPojoArrayList(ArrayList<SavedCategoryPojo> pojoArrayList) {
        this.pojoArrayList = pojoArrayList;
    }
}

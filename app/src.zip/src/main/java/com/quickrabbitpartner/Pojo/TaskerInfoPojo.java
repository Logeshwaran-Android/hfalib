package com.quickrabbitpartner.Pojo;

/**
 * Created by CAS63 on 7/11/2018.
 */

public class TaskerInfoPojo {
    private String TaskerName = "";
    private String TaskerEmail = "";
    private String TaskerGender = "";
    private String TaskerDOB = "";
    private String TaskerCountryCde = "";
    private String TaskerMblNumbr = "";
    private String TaskerPswrd = "";
    private String TaskerAddress = "";
    private String TaskerState = "";
    private String TaskerTown = "";
    private String TaskerCountry = "";
    private String TaskerWrkLocation = "";
    private String TaskerRadius = "";
    private String TaskerZipCode = "";
    private String TaskerAddressLat = "";
    private String TaskerAddressLng = "";
    private String TaskerWork_lat="";
    private String TaskerWork_long="";
    private String Tasker_Image_url="";





    public String getTaskerWork_lat() {
        return TaskerWork_lat;
    }

    public void setTaskerWork_lat(String taskerWork_lat) {
        TaskerWork_lat = taskerWork_lat;
    }

    public String getTaskerWork_long() {
        return TaskerWork_long;
    }

    public void setTaskerWork_long(String taskerWork_long) {
        TaskerWork_long = taskerWork_long;
    }

    public String getTasker_Image_url() {
        return Tasker_Image_url;
    }

    public void setTasker_Image_url(String tasker_Image_url) {
        Tasker_Image_url = tasker_Image_url;
    }



    public String getTaskerAddressLat() {
        return TaskerAddressLat;
    }

    public void setTaskerAddressLat(String taskerAddressLat) {
        TaskerAddressLat = taskerAddressLat;
    }

    public String getTaskerAddressLng() {
        return TaskerAddressLng;
    }

    public void setTaskerAddressLng(String taskerAddressLng) {
        TaskerAddressLng = taskerAddressLng;
    }

    public String getTaskerZipCode() {
        return TaskerZipCode;
    }

    public void setTaskerZipCode(String taskerZipCode) {
        TaskerZipCode = taskerZipCode;
    }

    public String getTaskerName() {
        return TaskerName;
    }

    public void setTaskerName(String taskerName) {
        TaskerName = taskerName;
    }

    public String getTaskerEmail() {
        return TaskerEmail;
    }

    public void setTaskerEmail(String taskerEmail) {
        TaskerEmail = taskerEmail;
    }

    public String getTaskerGender() {
        return TaskerGender;
    }

    public void setTaskerGender(String taskerGender) {
        TaskerGender = taskerGender;
    }

    public String getTaskerDOB() {
        return TaskerDOB;
    }

    public void setTaskerDOB(String taskerDOB) {
        TaskerDOB = taskerDOB;
    }

    public String getTaskerCountryCde() {
        return TaskerCountryCde;
    }

    public void setTaskerCountryCde(String taskerCountryCde) {
        TaskerCountryCde = taskerCountryCde;
    }

    public String getTaskerMblNumbr() {
        return TaskerMblNumbr;
    }

    public void setTaskerMblNumbr(String taskerMblNumbr) {
        TaskerMblNumbr = taskerMblNumbr;
    }

    public String getTaskerPswrd() {
        return TaskerPswrd;
    }

    public void setTaskerPswrd(String taskerPswrd) {
        TaskerPswrd = taskerPswrd;
    }

    public String getTaskerAddress() {
        return TaskerAddress;
    }

    public void setTaskerAddress(String taskerAddress) {
        TaskerAddress = taskerAddress;
    }

    public String getTaskerState() {
        return TaskerState;
    }

    public void setTaskerState(String taskerState) {
        TaskerState = taskerState;
    }

    public String getTaskerTown() {
        return TaskerTown;
    }

    public void setTaskerTown(String taskerTown) {
        TaskerTown = taskerTown;
    }

    public String getTaskerCountry() {
        return TaskerCountry;
    }

    public void setTaskerCountry(String taskerCountry) {
        TaskerCountry = taskerCountry;
    }

    public String getTaskerWrkLocation() {
        return TaskerWrkLocation;
    }

    public void setTaskerWrkLocation(String taskerWrkLocation) {
        TaskerWrkLocation = taskerWrkLocation;
    }

    public String getTaskerRadius() {
        return TaskerRadius;
    }

    public void setTaskerRadius(String taskerRadius) {
        TaskerRadius = taskerRadius;
    }
}

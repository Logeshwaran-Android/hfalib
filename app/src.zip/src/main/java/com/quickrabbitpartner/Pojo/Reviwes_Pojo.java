package com.quickrabbitpartner.Pojo;

/**
 * Created by user88 on 1/7/2016.
 */
public class Reviwes_Pojo {

    public String getOptions_title() {
        return options_title;
    }

    public void setOptions_title(String options_title) {
        this.options_title = options_title;
    }

    public String getOptions_id() {
        return options_id;
    }

    public void setOptions_id(String options_id) {
        this.options_id = options_id;
    }

    public String getRatings_count() {
        return ratings_count;
    }

    public void setRatings_count(String ratings_count) {
        this.ratings_count = ratings_count;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    private String options_title;
    private String options_id;
    private  String ratings_count;
    private String total;
}

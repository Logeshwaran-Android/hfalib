package com.quickrabbitpartner.Pojo;

/**
 * Created by user88 on 12/15/2015.
 */
public class MissedLeads_Pojo {

    private String  missedleads_order_id;
    private String  missedleads_user_name;
    private String  missedleads_user_image;

    public String getMossedleads_jobstatus() {
        return mossedleads_jobstatus;
    }

    public void setMossedleads_jobstatus(String mossedleads_jobstatus) {
        this.mossedleads_jobstatus = mossedleads_jobstatus;
    }

    private String mossedleads_jobstatus;

    public String getMissedleads_jobTime() {
        return missedleads_jobTime;
    }

    public void setMissedleads_jobTime(String missedleads_jobTime) {
        this.missedleads_jobTime = missedleads_jobTime;
    }

    private String  missedleads_location;
    private String  missedleads_jobTime;

    public String getMissedleads_jobtype() {
        return missedleads_jobtype;
    }

    public void setMissedleads_jobtype(String missedleads_jobtype) {
        this.missedleads_jobtype = missedleads_jobtype;
    }

    private String  missedleads_jobtype;

    public String getMissedleads_order_id() {
        return missedleads_order_id;
    }

    public void setMissedleads_order_id(String missedleads_order_id) {
        this.missedleads_order_id = missedleads_order_id;
    }

    public String getMissedleads_user_name() {
        return missedleads_user_name;
    }

    public void setMissedleads_user_name(String missedleads_user_name) {
        this.missedleads_user_name = missedleads_user_name;
    }

    public String getMissedleads_user_image() {
        return missedleads_user_image;
    }

    public void setMissedleads_user_image(String missedleads_user_image) {
        this.missedleads_user_image = missedleads_user_image;
    }

    public String getMissedleads_location() {
        return missedleads_location;
    }

    public void setMissedleads_location(String missedleads_location) {
        this.missedleads_location = missedleads_location;
    }

    public String getMissedleads_category() {
        return missedleads_category;
    }

    public void setMissedleads_category(String missedleads_category) {
        this.missedleads_category = missedleads_category;
    }

    public String getMissedleads_jabtimeand_date() {
        return missedleads_jabtimeand_date;
    }

    public void setMissedleads_jabtimeand_date(String missedleads_jabtimeand_date) {
        this.missedleads_jabtimeand_date = missedleads_jabtimeand_date;
    }

    private String  missedleads_category;
    private String  missedleads_jabtimeand_date;
}

package com.quickrabbitpartner.Pojo;

public class NewAvailabilityPojo {
    private String _id = "";
    private String endTime = "";
    private String startTime = "";
    private String to = "";
    private String from = "";
    private String day = "";
    private String wholeday = "";
    private String selected = "";

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getWholeday() {
        return wholeday;
    }

    public void setWholeday(String wholeday) {
        this.wholeday = wholeday;
    }

    public String getSelected() {
        return selected;
    }

    public void setSelected(String selected) {
        this.selected = selected;
    }
}

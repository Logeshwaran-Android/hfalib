package com.quickrabbitpartner.Pojo;

import java.util.ArrayList;

public class AvailabileArrayPojo {

    private ArrayList<RegistrastionAvailabilityChildPojo> pojoArrayList;

    public ArrayList<RegistrastionAvailabilityChildPojo> getPojoArrayList() {
        return pojoArrayList;
    }

    public void setPojoArrayList(ArrayList<RegistrastionAvailabilityChildPojo> pojoArrayList) {
        this.pojoArrayList = pojoArrayList;
    }
}

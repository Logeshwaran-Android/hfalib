package com.quickrabbitpartner.Pojo;

/**
 * Created by user88 on 12/12/2015.
 */
public class MyjobConverted_Pojo {

    private String order_id;
    private String converted_user_name;
    private String converted_user_image;
    private String converted_address;
    private String converted_date;
    private String Address="";

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getConvertedjob_status() {
        return convertedjob_status;
    }

    public void setConvertedjob_status(String convertedjob_status) {
        this.convertedjob_status = convertedjob_status;
    }

    private String convertedjob_status;

    public String getConverted_category() {
        return converted_category;
    }

    public void setConverted_category(String converted_category) {
        this.converted_category = converted_category;
    }

    private String converted_category;

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getConverted_user_name() {
        return converted_user_name;
    }

    public void setConverted_user_name(String converted_user_name) {
        this.converted_user_name = converted_user_name;
    }

    public String getConverted_user_image() {
        return converted_user_image;
    }

    public void setConverted_user_image(String converted_user_image) {
        this.converted_user_image = converted_user_image;
    }

    public String getConverted_address() {
        return converted_address;
    }

    public void setConverted_address(String converted_address) {
        this.converted_address = converted_address;
    }

    public String getConverted_date() {
        return converted_date;
    }

    public void setConverted_date(String converted_date) {
        this.converted_date = converted_date;
    }

    public String getConverted_time() {
        return converted_time;
    }

    public void setConverted_time(String converted_time) {
        this.converted_time = converted_time;
    }

    private String converted_time;

}

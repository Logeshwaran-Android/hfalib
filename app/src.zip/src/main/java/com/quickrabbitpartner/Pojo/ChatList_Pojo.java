package com.quickrabbitpartner.Pojo;

/**
 * Created by user88 on 2/3/2016.
 */
public class ChatList_Pojo {

   private String chatlist_image;
    private String chatlist_name;
    private String chatlist_plumbalId;

    public String getChatlist_jobId() {
        return chatlist_jobId;
    }

    public void setChatlist_jobId(String chatlist_jobId) {
        this.chatlist_jobId = chatlist_jobId;
    }

    public String getChatlist_image() {
        return chatlist_image;
    }

    public void setChatlist_image(String chatlist_image) {
        this.chatlist_image = chatlist_image;
    }

    public String getChatlist_name() {
        return chatlist_name;
    }

    public void setChatlist_name(String chatlist_name) {
        this.chatlist_name = chatlist_name;
    }

    public String getChatlist_plumbalId() {
        return chatlist_plumbalId;
    }

    public void setChatlist_plumbalId(String chatlist_plumbalId) {
        this.chatlist_plumbalId = chatlist_plumbalId;
    }

    public String getChatlist_message() {
        return chatlist_message;
    }

    public void setChatlist_message(String chatlist_message) {
        this.chatlist_message = chatlist_message;
    }

    public String getChatlist_messageTime() {
        return chatlist_messageTime;
    }

    public void setChatlist_messageTime(String chatlist_messageTime) {
        this.chatlist_messageTime = chatlist_messageTime;
    }

    private String chatlist_jobId;
    private String chatlist_message;
    private String chatlist_messageTime;


}

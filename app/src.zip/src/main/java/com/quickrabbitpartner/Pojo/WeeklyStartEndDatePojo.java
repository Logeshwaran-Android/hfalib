package com.quickrabbitpartner.Pojo;

public class WeeklyStartEndDatePojo {
    private String startWeekDate = "";
    private String endWeekDate = "";

    public String getStartWeekDate() {
        return startWeekDate;
    }

    public void setStartWeekDate(String startWeekDate) {
        this.startWeekDate = startWeekDate;
    }

    public String getEndWeekDate() {
        return endWeekDate;
    }

    public void setEndWeekDate(String endWeekDate) {
        this.endWeekDate = endWeekDate;
    }
}

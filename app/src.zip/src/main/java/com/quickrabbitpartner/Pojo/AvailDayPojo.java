package com.quickrabbitpartner.Pojo;


public class AvailDayPojo {
    private String DayName = "";
    private String DaySelected = "";

    public String getDayName() {
        return DayName;
    }

    public void setDayName(String dayName) {
        DayName = dayName;
    }

    public String getDaySelected() {
        return DaySelected;
    }

    public void setDaySelected(String daySelected) {
        DaySelected = daySelected;
    }
}

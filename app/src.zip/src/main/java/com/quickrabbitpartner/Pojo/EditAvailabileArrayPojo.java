package com.quickrabbitpartner.Pojo;

import java.util.ArrayList;

public class EditAvailabileArrayPojo {

    private ArrayList<MyProfileEditAvailabilityPojo> pojoArrayList;

    public ArrayList<MyProfileEditAvailabilityPojo> getPojoArrayList() {
        return pojoArrayList;
    }

    public void setPojoArrayList(ArrayList<MyProfileEditAvailabilityPojo> pojoArrayList) {
        this.pojoArrayList = pojoArrayList;
    }
}

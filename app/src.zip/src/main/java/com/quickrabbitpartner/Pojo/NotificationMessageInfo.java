package com.quickrabbitpartner.Pojo;

/**
 * Created by user145 on 2/14/2017.
 */
public class NotificationMessageInfo {

    private String NotificationMessageCreatedAt = "";
    private String NotificationMessage = "";


    public String getNotificationMessageCreatedAt() {
        return NotificationMessageCreatedAt;
    }

    public void setNotificationMessageCreatedAt(String notificationMessageCreatedAt) {
        NotificationMessageCreatedAt = notificationMessageCreatedAt;
    }

    public String getNotificationMessage() {
        return NotificationMessage;
    }

    public void setNotificationMessage(String notificationMessage) {
        NotificationMessage = notificationMessage;
    }
}

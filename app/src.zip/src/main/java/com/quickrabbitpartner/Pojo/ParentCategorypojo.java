package com.quickrabbitpartner.Pojo;

/**
 * Created by user145 on 5/30/2017.
 */
public class ParentCategorypojo {
    private String ParentCategory_name = "";
    private String ParentCategory_id = "";


    public String getParentCategory_name() {
        return ParentCategory_name;
    }

    public void setParentCategory_name(String categoryname) {
        this.ParentCategory_name = categoryname;
    }


    public String getParentCategoryID() {
        return ParentCategory_id;
    }

    public void setParentCategoryID(String categoryID) {
        this.ParentCategory_id = categoryID;
    }
}

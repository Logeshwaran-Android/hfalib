package com.quickrabbitpartner.Pojo;

/**
 * Created by user145 on 3/16/2017.
 */
public class Addmaterialpojo {

    private String toolname = "", toolcost = "";
    private int valuesPosition = 0;

    public int getValuesPosition() {
        return valuesPosition;
    }

    public void setValuesPosition(int valuesPosition) {
        this.valuesPosition = valuesPosition;
    }

    public String getToolname() {
        return toolname;
    }

    public void setToolname(String toolname) {
        this.toolname = toolname;
    }

    public String getToolcost() {
        return toolcost;
    }

    public void setToolcost(String toolcost) {
        this.toolcost = toolcost;
    }

}

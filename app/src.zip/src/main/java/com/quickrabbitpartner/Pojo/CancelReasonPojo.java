package com.quickrabbitpartner.Pojo;

/**
 * Created by user88 on 12/17/2015.
 */
public class CancelReasonPojo {

    private String cancelreason_id;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCancelreason_id() {
        return cancelreason_id;
    }

    public void setCancelreason_id(String cancelreason_id) {
        this.cancelreason_id = cancelreason_id;
    }

    private String reason;


}

package com.quickrabbitpartner.Pojo;

import java.util.ArrayList;

public class OldAvailabileArrayPojo {

    private ArrayList<RegistrastionAvailabilityPojo> pojoArrayList;

    public ArrayList<RegistrastionAvailabilityPojo> getPojoArrayList() {
        return pojoArrayList;
    }

    public void setPojoArrayList(ArrayList<RegistrastionAvailabilityPojo> pojoArrayList) {
        this.pojoArrayList = pojoArrayList;
    }
}

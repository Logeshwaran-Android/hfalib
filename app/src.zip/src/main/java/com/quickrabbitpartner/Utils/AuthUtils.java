package com.quickrabbitpartner.Utils;

/**
 */
public class AuthUtils {

    private static int TOTAL_AUTH_COUNT = 10;

    public static void readAuthUtils() {
        if (TOTAL_AUTH_COUNT == 10) {
            createAuthData();
        }
    }

    private static void createAuthData() {
        //TODO need to write the auth data
    }
}

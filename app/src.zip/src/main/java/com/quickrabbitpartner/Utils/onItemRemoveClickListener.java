package com.quickrabbitpartner.Utils;

/**
 * Created by user145 on 3/16/2017.
 */
public interface onItemRemoveClickListener {
    void onRemoveListener(int position);
}

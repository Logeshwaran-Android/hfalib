package com.quickrabbitpartner.Utils;

/**
 * Created by user88 on 12/10/2015.
 */
public interface GuillotineListener {
    void onGuillotineOpened();
    void onGuillotineClosed();
}
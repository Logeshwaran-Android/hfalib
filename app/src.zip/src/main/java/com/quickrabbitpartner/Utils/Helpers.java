package com.quickrabbitpartner.Utils;

import android.widget.EditText;

public class Helpers {
    public static String rS(EditText editText) {
        return editText.getText().toString().trim();
    }
}

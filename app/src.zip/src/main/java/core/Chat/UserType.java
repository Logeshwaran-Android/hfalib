package core.Chat;

/**
 * Created by user88 on 1/29/2016.
 */
public enum UserType {
    OTHER, SELF
};
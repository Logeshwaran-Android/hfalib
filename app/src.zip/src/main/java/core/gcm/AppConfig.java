package core.gcm;
 
public interface AppConfig
{

    String TAG = "GCM TAG";
    String REG_ID = "regId";
    String APP_VERSION = "app_version";
    String PARSE_CHANNEL = "PlumbalPartner";
    String PARSE_APPLICATION_ID = "647559268183";
    int NOTIFICATION_ID = 100;
}
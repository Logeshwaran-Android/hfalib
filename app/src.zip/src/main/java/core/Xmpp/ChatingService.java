
package core.Xmpp;

/**
 * Created by user88 on 1/11/2016. *
 * TODO: NEED TO REMOVE THE CLASS
 */


public class ChatingService {

}

